import React, { Component } from 'react'

const UserContext = React.createContext()

function UserProvider(props)  {
  // Context state
  const [player1,setPlayer1] = React.useState("");
  const [player2,setPlayer2] = React.useState("");
  
  React.useEffect(()=>{
    setPlayer1(props.players[0]);
    setPlayer2(props.players[1]);
  },[props.players]);

    return (
      <UserContext.Provider
        value={{
          player1,
          player2,
        }}
      >
        {props.children}
      </UserContext.Provider>
    )

}

export default UserContext

export { UserProvider }