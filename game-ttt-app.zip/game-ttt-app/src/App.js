import React from "react";
import logo from './logo.svg';
import './App.css';
import ReactDOM from "react-dom";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  useLocation,
  useHistory
} from "react-router-dom";
import Home from './Home';
import Game from './Game';
import UserContext, { UserProvider } from "./UserContext";

function App(props) { 
  let [player1,setPlayer1] = React.useState("");
  let [player2,setPlayer2] = React.useState("");
  let [gameStatus,setGameStatus] = React.useState("");
  const history = useHistory();
  const submitHandler=(player1,player2)=>{
    if(player1 && player2 && player1 != "" && player2 != ""){
      setPlayer1(player1);
      setPlayer2(player2);
      setGameStatus("Continue");
      history.push("/game");
    }else{
      alert("Please provide names of both the players to proceed!!");
    }
  }

  const onGameChangeStatus=(status) => {
    setGameStatus(status);
  }

  return (
    <div>
    <UserProvider players={[player1,player2]} gameStatus={gameStatus}>
      <Switch>
        <Route path="/game" onGameChangeStatus={onGameChangeStatus} status={gameStatus}>
          <Game/>
        </Route>
        <Route path="/home" >
          <Home submitHandler={submitHandler}/>
        </Route>
      </Switch>
      </UserProvider>
    </div>
  );
}

export default App;
