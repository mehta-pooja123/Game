import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import Board from './Board';

function Home(props) {
    let [player1,setPlayer1] = React.useState("");
    let [player2,setPlayer2] = React.useState("");

const handleSubmit=(event)=> {
    event.preventDefault();
    props.submitHandler(player1,player2);
}

const inputChangeHandler1 = (event) => {
    setPlayer1(event.target.value);
  }

  const inputChangeHandler2 = (event) => {  
    setPlayer2(event.target.value);
  }



      return (
        <form onSubmit={(e)=>handleSubmit(e)}>     
            Player1: <input type="text" id="P1" onChange={inputChangeHandler1}/>
            Player2: <input type="text" id="P2" onChange={inputChangeHandler2}/><br/>
            <button type="submit">Lets Play!!</button>
        </form>
      );
    
  }

  export default Home;