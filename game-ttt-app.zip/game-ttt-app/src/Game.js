import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import Board from './Board';
import UserContext, { UserProvider } from "./UserContext";
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';

function Game(props) {
    const gamePlayers = React.useContext(UserContext);
      return (
        <div className="game">
         <Card style={{height:"50px",margin:"50px"}}>
            <CardContent>{gamePlayers.player1}</CardContent></Card>
          <div className="game-board">
            <Board onGameChangeStatus={props.onGameChangeStatus} status={props.status}/>
          </div>
          <Card style={{height:"50px",margin:"50px"}}><CardContent>{gamePlayers.player2}</CardContent></Card>
        </div>
      );
    }


  export default Game;